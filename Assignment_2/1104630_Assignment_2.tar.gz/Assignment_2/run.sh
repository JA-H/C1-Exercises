#! /bin/bash

#COMPILATION
make Assignment_2

#RUN COMMANDS
./Assignment_2 1 1 0.1 12
./Assignment_2 2 1 0.1 12
./Assignment_2 1 2 0.1 12
./Assignment_2 2 2 0.1 12
./Assignment_2 1 3 0.1 12
./Assignment_2 2 3 0.1 12
./Assignment_2 1 4 0.1 12
./Assignment_2 2 4 0.1 12
./Assignment_2 1 5 0.1 12
./Assignment_2 2 5 0.1 12

echo "load 'FE.p'" | gnuplot -persist
echo "load 'BE.p'" | gnuplot -persist
echo "load 'CN.p'" | gnuplot -persist
echo "load 'Heun3.p'" | gnuplot -persist
echo "load '2DIRK.p'" | gnuplot -persist

#Delete Data Files
rm Model_1_DIRK_1_Tau_0.05.dat
rm Model_1_DIRK_1_Tau_0.1.dat
rm Model_1_DIRK_2_Tau_0.05.dat
rm Model_1_DIRK_2_Tau_0.1.dat
rm Model_1_DIRK_3_Tau_0.05.dat
rm Model_1_DIRK_3_Tau_0.1.dat
rm Model_1_DIRK_4_Tau_0.05.dat
rm Model_1_DIRK_4_Tau_0.1.dat
rm Model_1_DIRK_5_Tau_0.05.dat
rm Model_1_DIRK_5_Tau_0.1.dat
rm Model_2_DIRK_1_Tau_0.05.dat
rm Model_2_DIRK_1_Tau_0.1.dat
rm Model_2_DIRK_2_Tau_0.05.dat
rm Model_2_DIRK_2_Tau_0.1.dat
rm Model_2_DIRK_3_Tau_0.05.dat
rm Model_2_DIRK_3_Tau_0.1.dat
rm Model_2_DIRK_4_Tau_0.05.dat
rm Model_2_DIRK_4_Tau_0.1.dat
rm Model_2_DIRK_5_Tau_0.05.dat
rm Model_2_DIRK_5_Tau_0.1.dat

#pdflatex report.tex

