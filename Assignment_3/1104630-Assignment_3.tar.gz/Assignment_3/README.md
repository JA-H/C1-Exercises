README FILE

#HOW TO COMPILE
Type into terminal:
> chmod u+x run.sh

#HOW TO RUN BASH FILE
Type into terminal:

> ./run.sh

#FILES

main.cc 					: Main
Makefile					: Makes ./main
run.sh 						: Bash script



#PLOTTING SCRIPTS 			: GNUPlot scripts
	FE.p
	RK4.p
	MM.p



#GRAPHICS					: .png files
	FE.png
	RK4.png
	MM.png

#REPORT 					: Latex files
	report.aux
	report.log
	report.out
	report.pdf
	report.synctex.gz
	report.tex
